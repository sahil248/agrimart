package com.agrimart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgriMartApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgriMartApplication.class, args);
	}

}
