package com.agrimart.pojos;

import java.sql.Blob;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Inventory {

	
	private Integer id;
	private String farmerId;
	private String cropName;
	private String season;
	private String seedNumber;
	private boolean isOrganic;
	private double price;
	private double quantity;
	private Blob image;
	
	
	public Inventory() 
	{
		super();
		
	}


	public Integer getId() {
		return id;
	}

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @OneToOne
	public void setId(Integer id) {
		this.id = id;
	}


	public String getFarmerId() {
		return farmerId;
	}

    @OneToOne(mappedBy = "addharNumber")
    public void setFarmerId(String farmerId) {
		this.farmerId = farmerId;
	}


	public String getCropName() {
		return cropName;
	}


	public void setCropName(String cropName) {
		this.cropName = cropName;
	}


	public String getSeason() {
		return season;
	}


	public void setSeason(String season) {
		this.season = season;
	}


	public String getSeedNumber() {
		return seedNumber;
	}


	public void setSeedNumber(String seedNumber) {
		this.seedNumber = seedNumber;
	}


	public boolean getIsOrganic() {
		return isOrganic;
	}


	public void setIsOrganic(boolean isOrganic) {
		this.isOrganic = isOrganic;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public double getQuantity() {
		return quantity;
	}


	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}


	public Blob getImage() {
		return image;
	}


	public void setImage(Blob image) {
		this.image = image;
	}
	
	
	
	

}
