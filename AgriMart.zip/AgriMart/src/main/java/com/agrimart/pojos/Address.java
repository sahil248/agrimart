package com.agrimart.pojos;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Address {
	
	private String addharNumber;
	private String houseNo;
	private String street;
	private String cityVillage;
	private String district;
	private String pincode;
	
    public Address() {
		super();
		
	}

	public String getAddharNumber() {
		return addharNumber;
	}


	@Id
	@OneToOne(mappedBy ="addharNumber")
	public void setAddharNumber(String addharNumber) {
		this.addharNumber = addharNumber;
	}

	public String getHouseNo() {
		return houseNo;
	}

	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCityVillage() {
		return cityVillage;
	}

	public void setCityVillage(String cityVillage) {
		this.cityVillage = cityVillage;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	
	

}
