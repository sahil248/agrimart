package com.agrimart.pojos;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity

public class SampleOrders {

	private String orderId;
	private String dealerId;
	private String farmerId;
	private int inventoryId;
	private boolean status;
	
	
	public  SampleOrders() {
		super();
	}


	public String getOrderId() {
		return orderId;
	}

	@Id
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public String getDealerId() {
		return dealerId;
	}

	@OneToOne(mappedBy = "addharNumber")
	public void setDealerId(String dealerId) {
		this.dealerId = dealerId;
	}


	public String getFarmerId() {
		return farmerId;
	}

	@OneToOne(mappedBy = "addharNumber")
	public void setFarmerId(String farmerId) {
		this.farmerId = farmerId;
	}


	
	public int getInventoryId() {
		return inventoryId;
	}

	@OneToOne(mappedBy = "id")
	public void setInventoryId(int inventoryId) {
		this.inventoryId = inventoryId;
	}


	public boolean isStatus() {
		return status;
	}


	public void setStatus(boolean status) {
		this.status = status;
	}
	
	

}
