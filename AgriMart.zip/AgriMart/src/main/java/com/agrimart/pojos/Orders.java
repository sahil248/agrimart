package com.agrimart.pojos;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Orders {

	private Integer orderId;
	private String dealerId;
	private String farmerId;
	private int inventoryId;
	private double quantity;
	private double bill;
	private boolean status;
	
	
	public  Orders() {
		super();
	}


	public Integer getOrderId() {
		return orderId;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}


	public String getDealerId() {
		return dealerId;
	}

	@OneToOne(mappedBy = "addharNumber")
	public void setDealerId(String dealerId) {
		this.dealerId = dealerId;
	}


	public String getFarmerId() {
		return farmerId;
	}

	@OneToOne(mappedBy = "addharNumber")
	public void setFarmerId(String farmerId) {
		this.farmerId = farmerId;
	}

	

	public int getInventoryId() {
		return inventoryId;
	}

	@OneToOne(mappedBy = "id")
	public void setInventoryId(int inventoryId) {
		this.inventoryId = inventoryId;
	}


	public double getQuantity() {
		return quantity;
	}


	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}


	public double getBill() {
		return bill;
	}


	public void setBill(double bill) {
		this.bill = bill;
	}


	public boolean isStatus() {
		return status;
	}


	public void setStatus(boolean status) {
		this.status = status;
	}
	
	
	
}
